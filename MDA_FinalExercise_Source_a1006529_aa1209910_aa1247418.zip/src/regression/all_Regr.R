library(ISLR)

source("visulizing_Raphael.R") # generates plots to identify outliers

source("preProcessing.R") # stores the clean dataset in data


